namespace ExamSystem.Models;

// Delegate used by the exam-starting events (Exam -> Subject -> Student)
public delegate void ExamStartingEventHandler(object? sender, ExamStartingEventArgs e);

public class ExamStartingEventArgs : EventArgs
{
    public Exam Exam { get; }

    public ExamStartingEventArgs(Exam exam)
    {
        Exam = exam ?? throw new ArgumentNullException(nameof(exam));
    }
}
