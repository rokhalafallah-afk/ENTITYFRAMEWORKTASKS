namespace ExamSystem.Models;

public class Subject
{
    private static int _nextId;
    private readonly List<Student> _students = new();

    public int Id { get; }
    public string Name { get; }
    public IReadOnlyList<Student> Students => _students;

    // Raised when any exam of this subject starts; every enrolled student is subscribed to it
    public event ExamStartingEventHandler? ExamStartingNotification;

    public Subject(int id, string name)
    {
        Id = id;
        Name = name ?? throw new ArgumentNullException(nameof(name));
    }

    // Constructor chaining
    public Subject(string name) : this(++_nextId, name) { }

    public void Enroll(Student student)
    {
        ArgumentNullException.ThrowIfNull(student);
        if (_students.Contains(student)) return;

        _students.Add(student);
        ExamStartingNotification += student.OnExamStarting;
    }

    // Called by Exam so the subject hears about the exam starting
    public void AddExam(Exam exam)
    {
        ArgumentNullException.ThrowIfNull(exam);
        exam.ExamStarting += OnExamStarting;
    }

    private void OnExamStarting(object? sender, ExamStartingEventArgs e)
        => ExamStartingNotification?.Invoke(this, e);

    public override bool Equals(object? obj) => obj is Subject other && Id == other.Id;

    public override int GetHashCode() => Id.GetHashCode();

    public override string ToString() => $"{Name} ({_students.Count} students)";
}
