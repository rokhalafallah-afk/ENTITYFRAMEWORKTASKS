namespace ExamSystem.Models;

// Practice exam: shows the right answers after the student finishes the exam
public class PracticeExam : Exam
{
    public PracticeExam(Subject subject, int timeInMinutes, string logFilePath)
        : base(subject, timeInMinutes, logFilePath) { }

    // Constructor chaining
    public PracticeExam(Subject subject, string logFilePath)
        : this(subject, 20, logFilePath) { }

    public override void ShowExam()
    {
        Dictionary<Question, AnswerList> studentAnswers = TakeExam();

        Console.WriteLine();
        Console.WriteLine("=== Practice exam finished: review ===");

        int number = 1;
        foreach (Question question in Questions)
        {
            AnswerList chosen = studentAnswers[question];
            AnswerList correct = QuestionAnswerDictionary[question];
            string verdict = chosen.HasSameAnswersAs(correct) ? "correct" : "wrong";

            Console.WriteLine($"Q{number++}. {question.Body}");
            Console.WriteLine($"   Your answer : {chosen}");
            Console.WriteLine($"   Right answer: {correct}  [{verdict}]");
        }

        Console.WriteLine();
        Console.WriteLine($"Score: {Grade(studentAnswers)} / {TotalMarks}");
    }
}
