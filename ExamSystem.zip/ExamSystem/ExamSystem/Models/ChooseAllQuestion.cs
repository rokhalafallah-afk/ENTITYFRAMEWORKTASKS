namespace ExamSystem.Models;

public class ChooseAllQuestion : Question
{
    public ChooseAllQuestion(string header, string body, int marks, IEnumerable<string> choices)
        : base(header, body, marks, BuildAnswers(choices)) { }

    // Constructor chaining
    public ChooseAllQuestion(string header, string body, IEnumerable<string> choices)
        : this(header, body, 1, choices) { }

    public ChooseAllQuestion(ChooseAllQuestion other) : base(other) { }

    public override bool AllowsMultipleAnswers => true;

    public override object Clone() => new ChooseAllQuestion(this);

    public override void Display()
    {
        Console.WriteLine($"[{Header}] {Body} ({Marks} marks, choose all that apply)");
        foreach (Answer answer in Answers)
            Console.WriteLine($"   [ ] {answer}");
    }

    public override AnswerList ReadAnswer()
    {
        while (true)
        {
            string? input = Prompt("   Your choices (numbers separated by commas): ");
            if (input is null) return new AnswerList();

            string[] parts = input.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            var chosen = new AnswerList();
            bool valid = parts.Length > 0;

            foreach (string part in parts)
            {
                Answer? answer = null;
                if (int.TryParse(part, out int id))
                    answer = Answers.FirstOrDefault(a => a.Id == id);

                if (answer is null)
                {
                    valid = false;
                    break;
                }

                if (!chosen.Contains(answer))
                    chosen.Add(answer);
            }

            if (valid) return chosen;

            Console.WriteLine("   Please enter listed numbers separated by commas, e.g. 1,3.");
        }
    }
}
