namespace ExamSystem.Models;

public class TrueFalseQuestion : Question
{
    public TrueFalseQuestion(string header, string body, int marks)
        : base(header, body, marks, new AnswerList { new Answer(1, "True"), new Answer(2, "False") }) { }

    // Constructor chaining
    public TrueFalseQuestion(string header, string body)
        : this(header, body, 1) { }

    public TrueFalseQuestion(TrueFalseQuestion other) : base(other) { }

    public override object Clone() => new TrueFalseQuestion(this);

    public override void Display()
    {
        Console.WriteLine($"[{Header}] {Body} ({Marks} marks)");
        Console.WriteLine("   True / False");
    }

    public override AnswerList ReadAnswer()
    {
        while (true)
        {
            string? input = Prompt("   Your answer (T/F): ");
            if (input is null) return new AnswerList();

            switch (input.Trim().ToLowerInvariant())
            {
                case "t":
                case "true":
                    return new AnswerList { Answers.First(a => a.Id == 1) };
                case "f":
                case "false":
                    return new AnswerList { Answers.First(a => a.Id == 2) };
            }

            Console.WriteLine("   Please enter T or F.");
        }
    }
}
