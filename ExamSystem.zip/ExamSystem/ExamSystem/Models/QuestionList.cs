namespace ExamSystem.Models;

// Question list that inherits List<T>. The generic constraint guarantees only Questions are stored.
// Every question added is also logged to the file of THIS list (each list has its own file).
public class QuestionList<T> : List<T> where T : Question
{
    public string LogFilePath { get; }

    public QuestionList(string logFilePath)
    {
        if (string.IsNullOrWhiteSpace(logFilePath))
            throw new ArgumentException("A log file path is required.", nameof(logFilePath));

        LogFilePath = Path.GetFullPath(logFilePath);

        string? directory = Path.GetDirectoryName(LogFilePath);
        if (!string.IsNullOrEmpty(directory))
            Directory.CreateDirectory(directory);

        File.WriteAllText(LogFilePath,
            $"# Question log created {DateTime.Now:yyyy-MM-dd HH:mm:ss}{Environment.NewLine}");
    }

    // List<T>.Add is not virtual, so it is hidden with 'new': the default behaviour is kept
    // (base.Add) and the logging is added. Use this through a QuestionList<T> reference.
    public new void Add(T item)
    {
        ArgumentNullException.ThrowIfNull(item);

        base.Add(item);

        using TextWriter writer = new StreamWriter(LogFilePath, append: true);
        writer.WriteLine($"{DateTime.Now:HH:mm:ss} | {item}");
    }

    // AddRange would bypass the logging, so route it through Add
    public new void AddRange(IEnumerable<T> items)
    {
        foreach (T item in items)
            Add(item);
    }

    public string ReadLog()
    {
        if (!File.Exists(LogFilePath)) return string.Empty;

        using TextReader reader = new StreamReader(LogFilePath);
        return reader.ReadToEnd();
    }
}
