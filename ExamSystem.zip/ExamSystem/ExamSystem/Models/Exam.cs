namespace ExamSystem.Models;

// Base class: the attributes common to every exam. ShowExam is implemented by the derived exams.
public abstract class Exam : IComparable<Exam>
{
    private ExamMode _mode = ExamMode.Queued;

    public Subject Subject { get; }
    public int TimeInMinutes { get; }
    public QuestionList<Question> Questions { get; }

    // Question -> its correct answer(s). Used for exam correction.
    public Dictionary<Question, AnswerList> QuestionAnswerDictionary { get; } = new();

    public int NumberOfQuestions => Questions.Count;
    public int TotalMarks => Questions.Sum(q => q.Marks);

    // Raised when the exam goes into Starting mode
    public event ExamStartingEventHandler? ExamStarting;

    public ExamMode Mode
    {
        get => _mode;
        set
        {
            if (_mode == value) return;
            _mode = value;

            if (_mode == ExamMode.Starting)
                OnExamStarting();
        }
    }

    protected Exam(Subject subject, int timeInMinutes, QuestionList<Question> questions)
    {
        if (timeInMinutes <= 0)
            throw new ArgumentOutOfRangeException(nameof(timeInMinutes), "Time must be positive.");

        Subject = subject ?? throw new ArgumentNullException(nameof(subject));
        TimeInMinutes = timeInMinutes;
        Questions = questions ?? throw new ArgumentNullException(nameof(questions));

        // The subject listens to this exam so it can notify its students
        Subject.AddExam(this);
    }

    // Constructor chaining
    protected Exam(Subject subject, int timeInMinutes, string logFilePath)
        : this(subject, timeInMinutes, new QuestionList<Question>(logFilePath)) { }

    protected Exam(Subject subject, string logFilePath)
        : this(subject, 60, logFilePath) { }

    protected virtual void OnExamStarting()
        => ExamStarting?.Invoke(this, new ExamStartingEventArgs(this));

    // correctAnswerIds are the Ids of the right answers among the question's own answers
    public void AddQuestion(Question question, params int[] correctAnswerIds)
    {
        ArgumentNullException.ThrowIfNull(question);

        if (QuestionAnswerDictionary.ContainsKey(question))
            throw new ArgumentException($"The exam already contains '{question.Header}'.", nameof(question));

        var correct = new AnswerList();
        foreach (int id in correctAnswerIds)
        {
            Answer? answer = question.Answers.FirstOrDefault(a => a.Id == id);
            if (answer is null)
                throw new ArgumentException($"'{question.Header}' has no answer with id {id}.", nameof(correctAnswerIds));
            correct.Add(answer);
        }

        if (correct.Count == 0)
            throw new ArgumentException("At least one correct answer is required.", nameof(correctAnswerIds));

        if (!question.AllowsMultipleAnswers && correct.Count > 1)
            throw new ArgumentException($"'{question.Header}' accepts a single correct answer.", nameof(correctAnswerIds));

        Questions.Add(question);                    // logs the question to this exam's file
        QuestionAnswerDictionary[question] = correct;
    }

    // Implementation differs per exam type
    public abstract void ShowExam();

    // Shows every question, reads the student's answers
    protected Dictionary<Question, AnswerList> TakeExam()
    {
        var studentAnswers = new Dictionary<Question, AnswerList>();

        Console.WriteLine($"=== {GetType().Name}: {Subject.Name} ===");
        Console.WriteLine($"Time: {TimeInMinutes} min | Questions: {NumberOfQuestions} | Marks: {TotalMarks}");

        int number = 1;
        foreach (Question question in Questions)
        {
            Console.WriteLine();
            Console.Write($"Q{number++}. ");
            question.Display();
            studentAnswers[question] = question.ReadAnswer();
        }

        return studentAnswers;
    }

    // Exam correction: compares the student's answers with QuestionAnswerDictionary
    protected int Grade(Dictionary<Question, AnswerList> studentAnswers)
    {
        int score = 0;
        foreach (var (question, correct) in QuestionAnswerDictionary)
        {
            if (studentAnswers.TryGetValue(question, out AnswerList? chosen) && chosen.HasSameAnswersAs(correct))
                score += question.Marks;
        }
        return score;
    }

    public int CompareTo(Exam? other)
        => other is null ? 1 : TimeInMinutes.CompareTo(other.TimeInMinutes);

    public override string ToString()
        => $"{GetType().Name} - {Subject.Name} | {NumberOfQuestions} questions | {TotalMarks} marks | {TimeInMinutes} min | Mode: {Mode}";
}
