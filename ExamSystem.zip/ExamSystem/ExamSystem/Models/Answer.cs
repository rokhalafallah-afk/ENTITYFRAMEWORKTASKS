namespace ExamSystem.Models;

public class Answer : ICloneable, IComparable<Answer>
{
    public int Id { get; }
    public string Text { get; }

    public Answer(int id, string text)
    {
        Id = id;
        Text = text ?? throw new ArgumentNullException(nameof(text));
    }

    // Constructor chaining
    public Answer(string text) : this(0, text) { }

    public object Clone() => new Answer(Id, Text);

    public int CompareTo(Answer? other) => other is null ? 1 : Id.CompareTo(other.Id);

    public override bool Equals(object? obj)
        => obj is Answer other && Id == other.Id && Text == other.Text;

    public override int GetHashCode() => HashCode.Combine(Id, Text);

    public override string ToString() => $"{Id}. {Text}";
}
