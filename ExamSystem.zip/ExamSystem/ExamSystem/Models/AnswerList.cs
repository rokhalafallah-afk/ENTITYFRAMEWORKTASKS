namespace ExamSystem.Models;

public class AnswerList : List<Answer>
{
    // Constructor chaining
    public AnswerList() : this(Enumerable.Empty<Answer>()) { }

    public AnswerList(IEnumerable<Answer> answers) : base(answers) { }

    // True when both lists hold exactly the same answers (order does not matter)
    public bool HasSameAnswersAs(AnswerList other)
        => Count == other.Count
           && this.Select(a => a.Id).OrderBy(id => id)
                  .SequenceEqual(other.Select(a => a.Id).OrderBy(id => id));

    public override string ToString()
        => Count == 0 ? "(no answer)" : string.Join(", ", this.Select(a => a.Text));
}
