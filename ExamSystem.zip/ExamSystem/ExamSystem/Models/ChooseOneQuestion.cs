namespace ExamSystem.Models;

public class ChooseOneQuestion : Question
{
    public ChooseOneQuestion(string header, string body, int marks, IEnumerable<string> choices)
        : base(header, body, marks, BuildAnswers(choices)) { }

    // Constructor chaining
    public ChooseOneQuestion(string header, string body, IEnumerable<string> choices)
        : this(header, body, 1, choices) { }

    public ChooseOneQuestion(ChooseOneQuestion other) : base(other) { }

    public override object Clone() => new ChooseOneQuestion(this);

    public override void Display()
    {
        Console.WriteLine($"[{Header}] {Body} ({Marks} marks)");
        foreach (Answer answer in Answers)
            Console.WriteLine($"   ( ) {answer}");
    }

    public override AnswerList ReadAnswer()
    {
        while (true)
        {
            string? input = Prompt("   Your choice (number): ");
            if (input is null) return new AnswerList();

            if (int.TryParse(input.Trim(), out int id))
            {
                Answer? chosen = Answers.FirstOrDefault(a => a.Id == id);
                if (chosen is not null)
                    return new AnswerList { chosen };
            }

            Console.WriteLine("   Please enter one of the listed numbers.");
        }
    }
}
