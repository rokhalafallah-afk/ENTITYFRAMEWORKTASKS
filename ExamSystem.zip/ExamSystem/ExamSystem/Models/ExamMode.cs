namespace ExamSystem.Models;

public enum ExamMode
{
    Starting,
    Queued,
    Finished
}
