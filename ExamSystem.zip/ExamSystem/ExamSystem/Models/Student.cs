namespace ExamSystem.Models;

public class Student
{
    private static int _nextId;

    public int Id { get; }
    public string Name { get; }

    public Student(int id, string name)
    {
        Id = id;
        Name = name ?? throw new ArgumentNullException(nameof(name));
    }

    // Constructor chaining
    public Student(string name) : this(++_nextId, name) { }

    // Event handler: called when an exam of a subject this student takes goes into Starting mode
    public void OnExamStarting(object? sender, ExamStartingEventArgs e)
    {
        Console.WriteLine(
            $"[Notification] {Name}: the {e.Exam.GetType().Name} for '{e.Exam.Subject.Name}' " +
            $"is starting now ({e.Exam.TimeInMinutes} min, {e.Exam.NumberOfQuestions} questions).");
    }

    public override bool Equals(object? obj) => obj is Student other && Id == other.Id;

    public override int GetHashCode() => Id.GetHashCode();

    public override string ToString() => $"Student #{Id}: {Name}";
}
