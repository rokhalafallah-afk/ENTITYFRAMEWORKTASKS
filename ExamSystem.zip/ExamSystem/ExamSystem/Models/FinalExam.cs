namespace ExamSystem.Models;

// Final exam: only shows the questions and the student's answers, never the right answers
public class FinalExam : Exam
{
    public FinalExam(Subject subject, int timeInMinutes, string logFilePath)
        : base(subject, timeInMinutes, logFilePath) { }

    // Constructor chaining
    public FinalExam(Subject subject, string logFilePath)
        : this(subject, 30, logFilePath) { }

    public override void ShowExam()
    {
        Dictionary<Question, AnswerList> studentAnswers = TakeExam();

        Console.WriteLine();
        Console.WriteLine("=== Final exam submitted ===");

        int number = 1;
        foreach (Question question in Questions)
        {
            Console.WriteLine($"Q{number++}. {question.Body}");
            Console.WriteLine($"   Your answer: {studentAnswers[question]}");
        }

        Console.WriteLine();
        Console.WriteLine($"Score: {Grade(studentAnswers)} / {TotalMarks}");
    }
}
