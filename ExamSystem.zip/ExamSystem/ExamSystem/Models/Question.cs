namespace ExamSystem.Models;

// Base class for every question type. Each question is associated with an AnswerList.
public abstract class Question : ICloneable, IComparable<Question>
{
    public string Header { get; }
    public string Body { get; }
    public int Marks { get; }
    public AnswerList Answers { get; }

    protected Question(string header, string body, int marks, AnswerList answers)
    {
        if (marks <= 0)
            throw new ArgumentOutOfRangeException(nameof(marks), "Marks must be positive.");

        Header = header ?? throw new ArgumentNullException(nameof(header));
        Body = body ?? throw new ArgumentNullException(nameof(body));
        Marks = marks;
        Answers = answers ?? throw new ArgumentNullException(nameof(answers));
    }

    // Constructor chaining
    protected Question(string header, string body, int marks)
        : this(header, body, marks, new AnswerList()) { }

    protected Question(string header, string body)
        : this(header, body, 1) { }

    // Copy constructor (deep copies the answers) used by Clone()
    protected Question(Question other)
        : this(other.Header, other.Body, other.Marks,
               new AnswerList(other.Answers.Select(a => (Answer)a.Clone()))) { }

    // Whether more than one answer can be correct (Choose All only)
    public virtual bool AllowsMultipleAnswers => false;

    // Each question type has its own way of being represented and answered
    public abstract void Display();
    public abstract AnswerList ReadAnswer();
    public abstract object Clone();

    protected static AnswerList BuildAnswers(IEnumerable<string> choices)
    {
        var answers = new AnswerList();
        int id = 1;
        foreach (string choice in choices)
            answers.Add(new Answer(id++, choice));

        if (answers.Count < 2)
            throw new ArgumentException("A question needs at least two choices.", nameof(choices));

        return answers;
    }

    protected static string? Prompt(string message)
    {
        Console.Write(message);
        return Console.ReadLine();
    }

    public int CompareTo(Question? other)
    {
        if (other is null) return 1;
        int byMarks = Marks.CompareTo(other.Marks);
        return byMarks != 0 ? byMarks : string.Compare(Header, other.Header, StringComparison.Ordinal);
    }

    // Used as the key of Exam.QuestionAnswerDictionary, so equality is based on read-only data
    public override bool Equals(object? obj)
        => obj is Question other && Header == other.Header && Body == other.Body;

    public override int GetHashCode() => HashCode.Combine(Header, Body);

    public override string ToString() => $"[{GetType().Name}] {Header}: {Body} ({Marks} marks)";
}
