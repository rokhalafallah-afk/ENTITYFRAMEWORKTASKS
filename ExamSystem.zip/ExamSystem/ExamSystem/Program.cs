using ExamSystem.Models;

// ---- Subject and the students taking it ----
var subject = new Subject("C# Object-Oriented Programming");
subject.Enroll(new Student("Rawan"));
subject.Enroll(new Student("Omar"));
subject.Enroll(new Student("Laila"));

// ---- Two exams: one practice, one final (each question list logs to its own file) ----
var practiceExam = new PracticeExam(subject, 20, Path.Combine("Logs", "practice-questions.log"));
var finalExam = new FinalExam(subject, 30, Path.Combine("Logs", "final-questions.log"));

// Practice exam questions (the numbers after the question are the ids of the right answers)
practiceExam.AddQuestion(
    new TrueFalseQuestion("Inheritance", "A derived class can directly access private members of its base class.", 2),
    2);
practiceExam.AddQuestion(
    new ChooseOneQuestion("Polymorphism", "Which keyword lets a derived class replace a virtual method?", 3,
        new[] { "virtual", "override", "sealed", "abstract" }),
    2);
practiceExam.AddQuestion(
    new ChooseAllQuestion("Classes", "Which of these can be instantiated directly with new?", 4,
        new[] { "abstract class", "concrete class", "interface", "sealed class" }),
    2, 4);

// Final exam questions
finalExam.AddQuestion(
    new TrueFalseQuestion("Interfaces", "An interface can contain a constructor.", 2),
    2);
finalExam.AddQuestion(
    new ChooseOneQuestion("Equality", "Which method should be overridden together with Equals?", 3,
        new[] { "GetHashCode", "Finalize", "Dispose", "Clone" }),
    1);
finalExam.AddQuestion(
    new ChooseAllQuestion("Access", "Which of these are C# access modifiers?", 4,
        new[] { "public", "internal", "protected", "friend" }),
    1, 2, 3);

// ---- The end user selects the exam type ----
Console.WriteLine("Select the exam type:");
Console.WriteLine("  1. Practice Exam");
Console.WriteLine("  2. Final Exam");

Exam? selected = null;
while (selected is null)
{
    Console.Write("Your choice: ");
    string? input = Console.ReadLine();
    if (input is null) return;

    if (input.Trim() == "1") selected = practiceExam;
    else if (input.Trim() == "2") selected = finalExam;
    else Console.WriteLine("Please enter 1 or 2.");
}

Console.WriteLine();
Console.WriteLine(selected);                 // mode is Queued
Console.WriteLine();

selected.Mode = ExamMode.Starting;           // every student of the subject is notified
Console.WriteLine();

selected.ShowExam();                         // practice and final behave differently

selected.Mode = ExamMode.Finished;
Console.WriteLine();
Console.WriteLine($"Exam mode: {selected.Mode}");

Console.WriteLine();
Console.WriteLine($"Questions logged to {selected.Questions.LogFilePath}:");
Console.WriteLine(selected.Questions.ReadLog());
