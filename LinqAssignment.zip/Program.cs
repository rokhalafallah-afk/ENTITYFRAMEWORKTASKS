using EF01;

// ------------------------------------------------------------
// Shared data used across multiple sections
// ------------------------------------------------------------
var products = ListGenerators.GetProductList();
var customers = ListGenerators.GetCustomerList();

string[] digitNames = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
int[] numbersArr = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
string[] caseWords = { "aPPLE", "AbAcUs", "bRaNcH", "BlUeBeRrY", "ClOvEr", "cHeRry" };

string dictPath = "dictionary_english.txt";
string[] dictionaryWords = File.Exists(dictPath)
    ? File.ReadAllLines(dictPath)
    : new[] { "apple", "receive", "believe", "friend", "weird", "science", "leisure", "neighbor", "ceiling", "height" };

// ==============================================================
// LINQ - RESTRICTION OPERATORS
// ==============================================================
PrintHeader("RESTRICTION 1: Products out of stock");
var outOfStock = from p in products
                  where p.UnitsInStock == 0
                  select p;
foreach (var p in outOfStock) Console.WriteLine($"{p.ProductName} - {p.UnitsInStock} in stock");

PrintHeader("RESTRICTION 2: In stock AND UnitPrice > 3.00");
var inStockPricey = from p in products
                     where p.UnitsInStock > 0 && p.UnitPrice > 3.00m
                     select p;
foreach (var p in inStockPricey) Console.WriteLine($"{p.ProductName} - {p.UnitPrice:C}");

PrintHeader("RESTRICTION 3: Digits whose name is shorter than their value");
var shortNamedDigits = digitNames.Where((name, index) => name.Length < index);
foreach (var d in shortNamedDigits) Console.WriteLine(d);

// ==============================================================
// LINQ - ELEMENT OPERATORS
// ==============================================================
PrintHeader("ELEMENT 1: First product out of stock");
var firstOutOfStock = products.First(p => p.UnitsInStock == 0);
Console.WriteLine($"{firstOutOfStock.ProductName}");

PrintHeader("ELEMENT 2: First product with Price > 1000, else null");
var firstExpensive = products.FirstOrDefault(p => p.UnitPrice > 1000m);
Console.WriteLine(firstExpensive is null ? "null (no product found)" : firstExpensive.ProductName);

PrintHeader("ELEMENT 3: Second number greater than 5");
var secondGreaterThan5 = numbersArr.Where(n => n > 5).Skip(1).First();
Console.WriteLine(secondGreaterThan5);

// ==============================================================
// LINQ - AGGREGATE OPERATORS
// ==============================================================
PrintHeader("AGGREGATE 1: Count of odd numbers");
int oddCount = numbersArr.Count(n => n % 2 != 0);
Console.WriteLine(oddCount);

PrintHeader("AGGREGATE 2: Customers and how many orders each has");
var customerOrderCounts = from c in customers
                           select new { c.CompanyName, OrderCount = c.Orders.Count };
foreach (var c in customerOrderCounts) Console.WriteLine($"{c.CompanyName}: {c.OrderCount} orders");

PrintHeader("AGGREGATE 3: Categories and how many products each has");
var categoryProductCounts = from p in products
                             group p by p.Category into g
                             select new { Category = g.Key, ProductCount = g.Count() };
foreach (var c in categoryProductCounts) Console.WriteLine($"{c.Category}: {c.ProductCount} products");

PrintHeader("AGGREGATE 4: Total of the numbers in the array");
Console.WriteLine(numbersArr.Sum());

PrintHeader("AGGREGATE 5: Total characters of all words in the dictionary");
Console.WriteLine(dictionaryWords.Sum(w => w.Length));

PrintHeader("AGGREGATE 6: Total units in stock per category");
var stockPerCategory = from p in products
                        group p by p.Category into g
                        select new { Category = g.Key, TotalUnits = g.Sum(p => p.UnitsInStock) };
foreach (var c in stockPerCategory) Console.WriteLine($"{c.Category}: {c.TotalUnits} units");

PrintHeader("AGGREGATE 7: Length of the shortest word in the dictionary");
Console.WriteLine(dictionaryWords.Min(w => w.Length));

PrintHeader("AGGREGATE 8: Cheapest price per category");
var cheapestPerCategory = from p in products
                           group p by p.Category into g
                           select new { Category = g.Key, Cheapest = g.Min(p => p.UnitPrice) };
foreach (var c in cheapestPerCategory) Console.WriteLine($"{c.Category}: {c.Cheapest:C}");

PrintHeader("AGGREGATE 9: Product(s) with the cheapest price per category (using let)");
var cheapestProductsPerCategory = from p in products
                                   group p by p.Category into g
                                   let minPrice = g.Min(p => p.UnitPrice)
                                   select new { Category = g.Key, Products = g.Where(p => p.UnitPrice == minPrice) };
foreach (var c in cheapestProductsPerCategory)
{
    Console.WriteLine(c.Category + ":");
    foreach (var p in c.Products) Console.WriteLine($"   {p.ProductName} - {p.UnitPrice:C}");
}

PrintHeader("AGGREGATE 10: Length of the longest word in the dictionary");
Console.WriteLine(dictionaryWords.Max(w => w.Length));

PrintHeader("AGGREGATE 11: Most expensive price per category");
var mostExpensivePerCategory = from p in products
                                group p by p.Category into g
                                select new { Category = g.Key, Highest = g.Max(p => p.UnitPrice) };
foreach (var c in mostExpensivePerCategory) Console.WriteLine($"{c.Category}: {c.Highest:C}");

PrintHeader("AGGREGATE 12: Product(s) with the most expensive price per category");
var mostExpensiveProductsPerCategory = from p in products
                                        group p by p.Category into g
                                        let maxPrice = g.Max(p => p.UnitPrice)
                                        select new { Category = g.Key, Products = g.Where(p => p.UnitPrice == maxPrice) };
foreach (var c in mostExpensiveProductsPerCategory)
{
    Console.WriteLine(c.Category + ":");
    foreach (var p in c.Products) Console.WriteLine($"   {p.ProductName} - {p.UnitPrice:C}");
}

PrintHeader("AGGREGATE 13: Average word length in the dictionary");
Console.WriteLine(dictionaryWords.Average(w => w.Length).ToString("0.##"));

PrintHeader("AGGREGATE 14: Average price per category");
var avgPricePerCategory = from p in products
                           group p by p.Category into g
                           select new { Category = g.Key, AvgPrice = g.Average(p => p.UnitPrice) };
foreach (var c in avgPricePerCategory) Console.WriteLine($"{c.Category}: {c.AvgPrice:C}");

// ==============================================================
// LINQ - ORDERING OPERATORS
// ==============================================================
PrintHeader("ORDERING 1: Products sorted by name");
foreach (var p in products.OrderBy(p => p.ProductName)) Console.WriteLine(p.ProductName);

PrintHeader("ORDERING 2: Case-insensitive sort using a custom comparer");
foreach (var w in caseWords.OrderBy(w => w, new CaseInsensitiveWordComparer())) Console.WriteLine(w);

PrintHeader("ORDERING 3: Products sorted by units in stock, highest to lowest");
foreach (var p in products.OrderByDescending(p => p.UnitsInStock))
    Console.WriteLine($"{p.ProductName}: {p.UnitsInStock}");

PrintHeader("ORDERING 4: Digits sorted by name length, then alphabetically");
foreach (var d in digitNames.OrderBy(d => d.Length).ThenBy(d => d)) Console.WriteLine(d);

PrintHeader("ORDERING 5: Words sorted by length, then case-insensitively");
foreach (var w in caseWords.OrderBy(w => w.Length).ThenBy(w => w, new CaseInsensitiveWordComparer()))
    Console.WriteLine(w);

PrintHeader("ORDERING 6: Products sorted by category, then price descending");
foreach (var p in products.OrderBy(p => p.Category).ThenByDescending(p => p.UnitPrice))
    Console.WriteLine($"{p.Category} | {p.ProductName} | {p.UnitPrice:C}");

PrintHeader("ORDERING 7: Words sorted by length, then case-insensitive descending");
foreach (var w in caseWords.OrderBy(w => w.Length).ThenByDescending(w => w, new CaseInsensitiveWordComparer()))
    Console.WriteLine(w);

PrintHeader("ORDERING 8: Digits whose second letter is 'i', reversed from original order");
var secondLetterI = digitNames.Where(d => d.Length > 1 && d[1] == 'i').Reverse();
foreach (var d in secondLetterI) Console.WriteLine(d);

// ==============================================================
// LINQ - TRANSFORMATION OPERATORS
// ==============================================================
PrintHeader("TRANSFORMATION 1: Sequence of just the product names");
foreach (var name in products.Select(p => p.ProductName)) Console.WriteLine(name);

PrintHeader("TRANSFORMATION 2: Upper/lower versions of each word (anonymous types)");
string[] mixedWords = { "aPPLE", "BlUeBeRrY", "cHeRry" };
var upperLower = mixedWords.Select(w => new { Upper = w.ToUpper(), Lower = w.ToLower() });
foreach (var w in upperLower) Console.WriteLine($"Upper: {w.Upper}, Lower: {w.Lower}");

PrintHeader("TRANSFORMATION 3: Product projection with UnitPrice renamed to Price");
var productPriceView = products.Select(p => new { p.ProductName, p.Category, Price = p.UnitPrice });
foreach (var p in productPriceView) Console.WriteLine($"{p.ProductName} ({p.Category}): {p.Price:C}");

PrintHeader("TRANSFORMATION 4: Do the values match their position in the array?");
var inPlace = numbersArr.Select((num, index) => new { Number = num, InPlace = num == index });
foreach (var n in inPlace) Console.WriteLine($"{n.Number}: {n.InPlace}");

PrintHeader("TRANSFORMATION 5: Pairs where a < b");
int[] numbersA = { 0, 2, 4, 5, 6, 8, 9 };
int[] numbersB = { 1, 3, 5, 7, 8 };
var pairs = from a in numbersA
            from b in numbersB
            where a < b
            select new { a, b };
foreach (var pair in pairs) Console.WriteLine($"{pair.a} is less than {pair.b}");

PrintHeader("TRANSFORMATION 6: Orders where the total is less than 500.00");
var smallOrders = from c in customers
                   from o in c.Orders
                   where o.Total < 500.00m
                   select new { c.CompanyName, o.OrderID, o.Total };
foreach (var o in smallOrders) Console.WriteLine($"{o.CompanyName} - Order {o.OrderID}: {o.Total:C}");

PrintHeader("TRANSFORMATION 7: Orders made in 1998 or later");
var recentOrders = from c in customers
                    from o in c.Orders
                    where o.OrderDate.Year >= 1998
                    select new { c.CompanyName, o.OrderID, o.OrderDate };
foreach (var o in recentOrders) Console.WriteLine($"{o.CompanyName} - Order {o.OrderID}: {o.OrderDate:d}");

// ==============================================================
// LINQ - PARTITIONING OPERATORS
// ==============================================================
var waOrders = from c in customers
               where c.Region == "WA"
               from o in c.Orders
               select new { c.CompanyName, o.OrderID, o.OrderDate };

PrintHeader("PARTITIONING 1: First 3 orders from customers in Washington");
foreach (var o in waOrders.Take(3)) Console.WriteLine($"{o.CompanyName} - Order {o.OrderID} ({o.OrderDate:d})");

PrintHeader("PARTITIONING 2: All but the first 2 orders from customers in Washington");
foreach (var o in waOrders.Skip(2)) Console.WriteLine($"{o.CompanyName} - Order {o.OrderID} ({o.OrderDate:d})");

int[] partitionNumbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

PrintHeader("PARTITIONING 3: TakeWhile a number is NOT less than its position");
var takeWhileResult = partitionNumbers.TakeWhile((n, index) => n >= index);
foreach (var n in takeWhileResult) Console.WriteLine(n);

PrintHeader("PARTITIONING 4: SkipWhile until the first element divisible by 3");
var skipWhileDivisible = partitionNumbers.SkipWhile(n => n % 3 != 0);
foreach (var n in skipWhileDivisible) Console.WriteLine(n);

PrintHeader("PARTITIONING 5: SkipWhile until the first element less than its position");
var skipWhileLessThanPos = partitionNumbers.SkipWhile((n, index) => n >= index);
foreach (var n in skipWhileLessThanPos) Console.WriteLine(n);

// ==============================================================
// LINQ - QUANTIFIERS
// ==============================================================
PrintHeader("QUANTIFIERS 1: Any dictionary word contain 'ei'?");
bool anyContainsEi = dictionaryWords.Any(w => w.Contains("ei"));
Console.WriteLine(anyContainsEi);

PrintHeader("QUANTIFIERS 2: Categories with at least one out-of-stock product");
var categoriesWithSomeOutOfStock = from p in products
                                    group p by p.Category into g
                                    where g.Any(p => p.UnitsInStock == 0)
                                    select g;
foreach (var g in categoriesWithSomeOutOfStock)
{
    Console.WriteLine(g.Key + ":");
    foreach (var p in g) Console.WriteLine($"   {p.ProductName} ({p.UnitsInStock} in stock)");
}

PrintHeader("QUANTIFIERS 3: Categories where ALL products are in stock");
var categoriesFullyInStock = from p in products
                              group p by p.Category into g
                              where g.All(p => p.UnitsInStock > 0)
                              select g;
foreach (var g in categoriesFullyInStock)
{
    Console.WriteLine(g.Key + ":");
    foreach (var p in g) Console.WriteLine($"   {p.ProductName} ({p.UnitsInStock} in stock)");
}

// ------------------------------------------------------------
// Local helper
// ------------------------------------------------------------
static void PrintHeader(string title)
{
    Console.WriteLine();
    Console.WriteLine("=== " + title + " ===");
}

// A custom IComparer<string> used for the "custom comparer" ordering questions
class CaseInsensitiveWordComparer : IComparer<string>
{
    public int Compare(string? x, string? y)
    {
        return string.Compare(x, y, StringComparison.OrdinalIgnoreCase);
    }
}
