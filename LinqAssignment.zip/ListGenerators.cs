namespace EF01
{
    // Stand-in for the ListGenerators.cs referenced in the assignment.
    // Replace GetProductList()/GetCustomerList() with your real file's data
    // if you're given one later -- the LINQ queries in Program.cs don't change.
    public static class ListGenerators
    {
        public static List<Product> GetProductList() => new()
        {
            new Product { ProductID = 1,  ProductName = "Chai",                             Category = "Beverages",      UnitPrice = 18.00m, UnitsInStock = 39 },
            new Product { ProductID = 2,  ProductName = "Chang",                            Category = "Beverages",      UnitPrice = 19.00m, UnitsInStock = 17 },
            new Product { ProductID = 3,  ProductName = "Aniseed Syrup",                    Category = "Condiments",     UnitPrice = 10.00m, UnitsInStock = 13 },
            new Product { ProductID = 4,  ProductName = "Chef Anton's Cajun Seasoning",     Category = "Condiments",     UnitPrice = 22.00m, UnitsInStock = 53 },
            new Product { ProductID = 5,  ProductName = "Chef Anton's Gumbo Mix",           Category = "Condiments",     UnitPrice = 21.35m, UnitsInStock = 0  },
            new Product { ProductID = 6,  ProductName = "Grandma's Boysenberry Spread",     Category = "Condiments",     UnitPrice = 25.00m, UnitsInStock = 120 },
            new Product { ProductID = 7,  ProductName = "Uncle Bob's Organic Dried Pears",  Category = "Produce",        UnitPrice = 30.00m, UnitsInStock = 15 },
            new Product { ProductID = 8,  ProductName = "Northwoods Cranberry Sauce",       Category = "Condiments",     UnitPrice = 40.00m, UnitsInStock = 6  },
            new Product { ProductID = 9,  ProductName = "Ikura",                            Category = "Seafood",        UnitPrice = 31.00m, UnitsInStock = 31 },
            new Product { ProductID = 10, ProductName = "Queso Cabrales",                   Category = "Dairy Products", UnitPrice = 21.00m, UnitsInStock = 22 },
            new Product { ProductID = 11, ProductName = "Queso Manchego La Pastora",        Category = "Dairy Products", UnitPrice = 38.00m, UnitsInStock = 0  },
            new Product { ProductID = 12, ProductName = "Konbu",                            Category = "Seafood",        UnitPrice = 6.00m,  UnitsInStock = 24 },
            new Product { ProductID = 13, ProductName = "Tofu",                             Category = "Produce",        UnitPrice = 23.25m, UnitsInStock = 35 },
            new Product { ProductID = 14, ProductName = "Genen Shouyu",                     Category = "Condiments",     UnitPrice = 15.50m, UnitsInStock = 39 },
            new Product { ProductID = 15, ProductName = "Pavlova",                          Category = "Produce",        UnitPrice = 17.45m, UnitsInStock = 29 },
        };

        public static List<Customer> GetCustomerList() => new()
        {
            new Customer
            {
                CustomerID = "ALFKI", CompanyName = "Alfreds Futterkiste", City = "Berlin", Region = "",
                Orders = new()
                {
                    new Order { OrderID = 10643, OrderDate = new DateTime(1997, 8, 25),  Total = 814.50m },
                    new Order { OrderID = 10692, OrderDate = new DateTime(1997, 10, 3),  Total = 878.00m },
                }
            },
            new Customer
            {
                CustomerID = "ANATR", CompanyName = "Ana Trujillo Emparedados", City = "Mexico City", Region = "",
                Orders = new()
                {
                    new Order { OrderID = 10308, OrderDate = new DateTime(1996, 9, 18), Total = 88.80m },
                }
            },
            new Customer
            {
                CustomerID = "LAZYK", CompanyName = "Lazy K Kountry Store", City = "Walla Walla", Region = "WA",
                Orders = new()
                {
                    new Order { OrderID = 10482, OrderDate = new DateTime(1997, 3, 21), Total = 224.82m },
                    new Order { OrderID = 10545, OrderDate = new DateTime(1998, 5, 13), Total = 21.49m  },
                }
            },
            new Customer
            {
                CustomerID = "TRAIH", CompanyName = "Trail's Head Gourmet Provisioners", City = "Kirkland", Region = "WA",
                Orders = new()
                {
                    new Order { OrderID = 10574, OrderDate = new DateTime(1997, 6, 19), Total = 630.00m },
                    new Order { OrderID = 10577, OrderDate = new DateTime(1998, 9, 1),  Total = 30.00m  },
                    new Order { OrderID = 10822, OrderDate = new DateTime(1998, 1, 8),  Total = 100.00m },
                }
            },
            new Customer
            {
                CustomerID = "WHITC", CompanyName = "White Clover Markets", City = "Seattle", Region = "WA",
                Orders = new()
                {
                    new Order { OrderID = 10269, OrderDate = new DateTime(1996, 7, 31), Total = 478.00m },
                    new Order { OrderID = 10344, OrderDate = new DateTime(1996, 11, 1), Total = 780.00m },
                    new Order { OrderID = 10469, OrderDate = new DateTime(1997, 3, 10), Total = 668.00m },
                    new Order { OrderID = 10483, OrderDate = new DateTime(1998, 3, 24), Total = 320.00m },
                    new Order { OrderID = 10504, OrderDate = new DateTime(1998, 4, 11), Total = 913.00m },
                }
            },
            new Customer
            {
                CustomerID = "LONEP", CompanyName = "Lonesome Pine Restaurant", City = "Portland", Region = "OR",
                Orders = new()
                {
                    new Order { OrderID = 10336, OrderDate = new DateTime(1996, 10, 10), Total = 382.00m },
                }
            },
        };
    }
}
